const router = require("express").Router();
const { authenticate, requireEmpresa } = require("../../middlewares/auth.middleware");
const { ok, created, notFound, badRequest } = require("../../utils/response");
const svc = require("./ventas.service");

router.use(authenticate, requireEmpresa);

router.get("/", async (req, res, next) => {
  try {
    return ok(res, await svc.listar(req.empresas_id));
  } catch (err) {
    next(err);
  }
});

router.get("/:id", async (req, res, next) => {
  try {
    const v = await svc.obtener(Number(req.params.id), req.empresas_id);
    if (!v) return notFound(res);
    return ok(res, v);
  } catch (err) {
    next(err);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const { fecha, canal, notas, clientes_id, items } = req.body;
    if (!fecha || !Array.isArray(items) || !items.length) return badRequest(res, "fecha e items son requeridos.");

    for (const i of items) {
      if (!i.productos_id || !i.cantidad || !i.precio_unitario)
        return badRequest(res, "Cada item requiere productos_id, cantidad y precio_unitario.");
    }

    const venta = await svc.crear(req.empresas_id, req.usuario.id, {
      fecha,
      canal,
      notas,
      clientes_id,
      items,
    });
    return created(res, venta);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
