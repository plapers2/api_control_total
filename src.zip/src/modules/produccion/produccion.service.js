const prisma = require("../../db/prisma");

const listar = async (empresasId) =>
  prisma.lotes_produccion.findMany({
    where: { empresas_id: empresasId },
    orderBy: { fecha: "desc" },
    include: {
      usuarios: true,
      lotes_produccion_items: { include: { productos: true } },
    },
  });

const obtener = async (id, empresasId) =>
  prisma.lotes_produccion.findFirst({
    where: { id, empresas_id: empresasId },
    include: {
      usuarios: true,
      lotes_produccion_items: { include: { productos: true } },
      movimientos_insumos: { include: { insumos: true } },
    },
  });

// Crear lote + items + descontar insumos según receta, todo atómico
const crear = async (empresasId, usuariosId, { fecha, notas, items }) => {
  // items = [{ productos_id, cantidad }, ...]
  return prisma.$transaction(async (tx) => {
    let costoTotal = 0;

    // Calcular costo y preparar movimientos de insumos
    const movimientos = [];
    for (const item of items) {
      const recetas = await tx.recetas.findMany({
        where: { productos_id: item.productos_id },
        include: { insumos: true },
      });

      for (const r of recetas) {
        const cantidadUsada = Number(r.cantidad) * item.cantidad;
        costoTotal += cantidadUsada * Number(r.insumos.precio_unidad ?? 0);

        movimientos.push({
          insumos_id: r.insumos_id,
          tipo: "salida",
          cantidad: cantidadUsada,
          costo_total: cantidadUsada * Number(r.insumos.precio_unidad ?? 0),
          nota: `Lote de producción`,
          usuarios_id: usuariosId,
        });

        // Descontar stock
        await tx.insumos.update({
          where: { id: r.insumos_id },
          data: { stock_actual: { decrement: cantidadUsada } },
        });
      }
    }

    // Crear el lote
    const lote = await tx.lotes_produccion.create({
      data: {
        empresas_id: empresasId,
        usuarios_id: usuariosId,
        fecha: new Date(fecha),
        notas,
        costo_total: costoTotal,
        lotes_produccion_items: {
          create: items.map((i) => ({
            productos_id: i.productos_id,
            cantidad: i.cantidad,
            costo_unitario: 0,
          })),
        },
      },
      include: { lotes_produccion_items: true },
    });

    // Registrar movimientos de insumos vinculados al lote
    await tx.movimientos_insumos.createMany({
      data: movimientos.map((m) => ({ ...m, lotes_produccion_id: lote.id })),
    });

    return lote;
  });
};

module.exports = { listar, obtener, crear };
